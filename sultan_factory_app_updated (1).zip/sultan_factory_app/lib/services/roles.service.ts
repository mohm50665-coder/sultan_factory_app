/**
 * Advanced Roles and Permissions System for Sultan Factory
 * Includes 10 roles and 30+ detailed permissions
 */

export type UserRole =
  | "admin"
  | "production_manager"
  | "warehouse_manager"
  | "sales_manager"
  | "maintenance_manager"
  | "financial_manager"
  | "hr_officer"
  | "quality_inspector"
  | "operator"
  | "user";

export interface Permission {
  id: string;
  nameAr: string;
  nameEn: string;
  descriptionAr: string;
  descriptionEn: string;
  category: string;
}

export interface RolePermissions {
  role: UserRole;
  permissions: Permission[];
  descriptionAr: string;
  descriptionEn: string;
  nameAr: string;
  nameEn: string;
}

// Define comprehensive permissions
const PERMISSIONS = {
  // Production permissions
  VIEW_PRODUCTION: {
    id: "view_production",
    nameAr: "عرض الإنتاج",
    nameEn: "View Production",
    descriptionAr: "عرض بيانات الإنتاج ومراحل التصنيع",
    descriptionEn: "View production data and manufacturing stages",
    category: "production",
  },
  ADD_PRODUCTION: {
    id: "add_production",
    nameAr: "إضافة إنتاج",
    nameEn: "Add Production",
    descriptionAr: "إدخال بيانات إنتاج جديدة",
    descriptionEn: "Enter new production data",
    category: "production",
  },
  EDIT_PRODUCTION: {
    id: "edit_production",
    nameAr: "تعديل الإنتاج",
    nameEn: "Edit Production",
    descriptionAr: "تعديل بيانات الإنتاج المدخلة",
    descriptionEn: "Edit entered production data",
    category: "production",
  },
  DELETE_PRODUCTION: {
    id: "delete_production",
    nameAr: "حذف الإنتاج",
    nameEn: "Delete Production",
    descriptionAr: "حذف بيانات الإنتاج",
    descriptionEn: "Delete production data",
    category: "production",
  },
  EXPORT_PRODUCTION: {
    id: "export_production",
    nameAr: "تصدير الإنتاج",
    nameEn: "Export Production",
    descriptionAr: "تصدير بيانات الإنتاج كتقارير",
    descriptionEn: "Export production data as reports",
    category: "production",
  },

  // Manufacturing stages permissions
  VIEW_MANUFACTURING: {
    id: "view_manufacturing",
    nameAr: "عرض مراحل التصنيع",
    nameEn: "View Manufacturing",
    descriptionAr: "عرض بيانات مراحل التصنيع المختلفة",
    descriptionEn: "View various manufacturing stage data",
    category: "manufacturing",
  },
  ADD_MANUFACTURING: {
    id: "add_manufacturing",
    nameAr: "إضافة بيانات التصنيع",
    nameEn: "Add Manufacturing Data",
    descriptionAr: "إدخال بيانات مراحل التصنيع",
    descriptionEn: "Enter manufacturing stage data",
    category: "manufacturing",
  },
  EDIT_MANUFACTURING: {
    id: "edit_manufacturing",
    nameAr: "تعديل بيانات التصنيع",
    nameEn: "Edit Manufacturing Data",
    descriptionAr: "تعديل بيانات مراحل التصنيع",
    descriptionEn: "Edit manufacturing stage data",
    category: "manufacturing",
  },

  // Warehouse permissions
  VIEW_WAREHOUSE: {
    id: "view_warehouse",
    nameAr: "عرض المستودع",
    nameEn: "View Warehouse",
    descriptionAr: "عرض بيانات المستودعات",
    descriptionEn: "View warehouse data",
    category: "warehouse",
  },
  MANAGE_WAREHOUSE_IN: {
    id: "manage_warehouse_in",
    nameAr: "إدارة الوارد",
    nameEn: "Manage Incoming",
    descriptionAr: "إدخال المواد والمنتجات للمستودع",
    descriptionEn: "Add materials and products to warehouse",
    category: "warehouse",
  },
  MANAGE_WAREHOUSE_OUT: {
    id: "manage_warehouse_out",
    nameAr: "إدارة الصادر",
    nameEn: "Manage Outgoing",
    descriptionAr: "إخراج المواد والمنتجات من المستودع",
    descriptionEn: "Remove materials and products from warehouse",
    category: "warehouse",
  },
  EDIT_WAREHOUSE: {
    id: "edit_warehouse",
    nameAr: "تعديل المستودع",
    nameEn: "Edit Warehouse",
    descriptionAr: "تعديل بيانات المستودع",
    descriptionEn: "Edit warehouse data",
    category: "warehouse",
  },
  DELETE_WAREHOUSE: {
    id: "delete_warehouse",
    nameAr: "حذف المستودع",
    nameEn: "Delete Warehouse",
    descriptionAr: "حذف بيانات المستودع",
    descriptionEn: "Delete warehouse data",
    category: "warehouse",
  },

  // Sales and Collection permissions
  VIEW_SALES: {
    id: "view_sales",
    nameAr: "عرض المبيعات",
    nameEn: "View Sales",
    descriptionAr: "عرض بيانات المبيعات",
    descriptionEn: "View sales data",
    category: "sales",
  },
  ADD_SALES: {
    id: "add_sales",
    nameAr: "إضافة مبيعات",
    nameEn: "Add Sales",
    descriptionAr: "إدخال بيانات مبيعات جديدة",
    descriptionEn: "Enter new sales data",
    category: "sales",
  },
  EDIT_SALES: {
    id: "edit_sales",
    nameAr: "تعديل المبيعات",
    nameEn: "Edit Sales",
    descriptionAr: "تعديل بيانات المبيعات",
    descriptionEn: "Edit sales data",
    category: "sales",
  },
  DELETE_SALES: {
    id: "delete_sales",
    nameAr: "حذف المبيعات",
    nameEn: "Delete Sales",
    descriptionAr: "حذف بيانات المبيعات",
    descriptionEn: "Delete sales data",
    category: "sales",
  },
  VIEW_COLLECTION: {
    id: "view_collection",
    nameAr: "عرض التحصيل",
    nameEn: "View Collection",
    descriptionAr: "عرض بيانات التحصيل",
    descriptionEn: "View collection data",
    category: "sales",
  },
  ADD_COLLECTION: {
    id: "add_collection",
    nameAr: "إضافة تحصيل",
    nameEn: "Add Collection",
    descriptionAr: "إدخال بيانات تحصيل جديدة",
    descriptionEn: "Enter new collection data",
    category: "sales",
  },

  // Maintenance permissions
  VIEW_MAINTENANCE: {
    id: "view_maintenance",
    nameAr: "عرض الصيانة",
    nameEn: "View Maintenance",
    descriptionAr: "عرض بيانات الصيانة",
    descriptionEn: "View maintenance data",
    category: "maintenance",
  },
  ADD_MAINTENANCE: {
    id: "add_maintenance",
    nameAr: "إضافة صيانة",
    nameEn: "Add Maintenance",
    descriptionAr: "إدخال طلبات صيانة جديدة",
    descriptionEn: "Enter new maintenance requests",
    category: "maintenance",
  },
  EDIT_MAINTENANCE: {
    id: "edit_maintenance",
    nameAr: "تعديل الصيانة",
    nameEn: "Edit Maintenance",
    descriptionAr: "تعديل بيانات الصيانة",
    descriptionEn: "Edit maintenance data",
    category: "maintenance",
  },
  DELETE_MAINTENANCE: {
    id: "delete_maintenance",
    nameAr: "حذف الصيانة",
    nameEn: "Delete Maintenance",
    descriptionAr: "حذف بيانات الصيانة",
    descriptionEn: "Delete maintenance data",
    category: "maintenance",
  },
  MANAGE_SAFETY: {
    id: "manage_safety",
    nameAr: "إدارة السلامة",
    nameEn: "Manage Safety",
    descriptionAr: "إدارة متطلبات السلامة والصحة المهنية",
    descriptionEn: "Manage safety and occupational health requirements",
    category: "maintenance",
  },

  // Financial permissions
  VIEW_FINANCIAL: {
    id: "view_financial",
    nameAr: "عرض المالية",
    nameEn: "View Financial",
    descriptionAr: "عرض البيانات المالية والمصروفات",
    descriptionEn: "View financial data and expenses",
    category: "financial",
  },
  ADD_FINANCIAL: {
    id: "add_financial",
    nameAr: "إضافة مصروفات",
    nameEn: "Add Expenses",
    descriptionAr: "إدخال مصروفات جديدة",
    descriptionEn: "Enter new expenses",
    category: "financial",
  },
  EDIT_FINANCIAL: {
    id: "edit_financial",
    nameAr: "تعديل المالية",
    nameEn: "Edit Financial",
    descriptionAr: "تعديل البيانات المالية",
    descriptionEn: "Edit financial data",
    category: "financial",
  },
  APPROVE_FINANCIAL: {
    id: "approve_financial",
    nameAr: "اعتماد المالية",
    nameEn: "Approve Financial",
    descriptionAr: "الموافقة على العمليات المالية",
    descriptionEn: "Approve financial transactions",
    category: "financial",
  },
  DELETE_FINANCIAL: {
    id: "delete_financial",
    nameAr: "حذف المالية",
    nameEn: "Delete Financial",
    descriptionAr: "حذف البيانات المالية",
    descriptionEn: "Delete financial data",
    category: "financial",
  },

  // Tasks permissions
  VIEW_TASKS: {
    id: "view_tasks",
    nameAr: "عرض المهام",
    nameEn: "View Tasks",
    descriptionAr: "عرض المهام المسندة",
    descriptionEn: "View assigned tasks",
    category: "tasks",
  },
  ADD_TASKS: {
    id: "add_tasks",
    nameAr: "إضافة مهام",
    nameEn: "Add Tasks",
    descriptionAr: "إنشاء مهام جديدة",
    descriptionEn: "Create new tasks",
    category: "tasks",
  },
  ASSIGN_TASKS: {
    id: "assign_tasks",
    nameAr: "تعيين المهام",
    nameEn: "Assign Tasks",
    descriptionAr: "تعيين المهام للموظفين",
    descriptionEn: "Assign tasks to employees",
    category: "tasks",
  },
  MANAGE_TASKS: {
    id: "manage_tasks",
    nameAr: "إدارة المهام",
    nameEn: "Manage Tasks",
    descriptionAr: "إدارة وتعديل وحذف المهام",
    descriptionEn: "Manage, edit, and delete tasks",
    category: "tasks",
  },

  // Human Resources permissions
  VIEW_HR: {
    id: "view_hr",
    nameAr: "عرض الموارد البشرية",
    nameEn: "View HR",
    descriptionAr: "عرض بيانات الموظفين والإجازات",
    descriptionEn: "View employee and leave data",
    category: "hr",
  },
  MANAGE_HR: {
    id: "manage_hr",
    nameAr: "إدارة الموارد البشرية",
    nameEn: "Manage HR",
    descriptionAr: "إدارة بيانات الموظفين والإجازات والحضور",
    descriptionEn: "Manage employee, leave, and attendance data",
    category: "hr",
  },
  VIEW_INJURIES: {
    id: "view_injuries",
    nameAr: "عرض الإصابات",
    nameEn: "View Injuries",
    descriptionAr: "عرض سجل إصابات العمل",
    descriptionEn: "View work injury records",
    category: "hr",
  },
  MANAGE_INJURIES: {
    id: "manage_injuries",
    nameAr: "إدارة الإصابات",
    nameEn: "Manage Injuries",
    descriptionAr: "إدارة سجل إصابات العمل",
    descriptionEn: "Manage work injury records",
    category: "hr",
  },

  // Admin and System permissions
  MANAGE_USERS: {
    id: "manage_users",
    nameAr: "إدارة المستخدمين",
    nameEn: "Manage Users",
    descriptionAr: "إضافة وتعديل وحذف المستخدمين",
    descriptionEn: "Add, edit, and delete users",
    category: "admin",
  },
  MANAGE_ROLES: {
    id: "manage_roles",
    nameAr: "إدارة الأدوار",
    nameEn: "Manage Roles",
    descriptionAr: "إدارة الأدوار والصلاحيات",
    descriptionEn: "Manage roles and permissions",
    category: "admin",
  },
  VIEW_REPORTS: {
    id: "view_reports",
    nameAr: "عرض التقارير",
    nameEn: "View Reports",
    descriptionAr: "عرض التقارير والإحصائيات",
    descriptionEn: "View reports and statistics",
    category: "admin",
  },
  EXPORT_REPORTS: {
    id: "export_reports",
    nameAr: "تصدير التقارير",
    nameEn: "Export Reports",
    descriptionAr: "تصدير التقارير والبيانات",
    descriptionEn: "Export reports and data",
    category: "admin",
  },
  VIEW_ACTIVITY_LOG: {
    id: "view_activity_log",
    nameAr: "عرض سجل النشاطات",
    nameEn: "View Activity Log",
    descriptionAr: "عرض سجل نشاطات المستخدمين",
    descriptionEn: "View user activity log",
    category: "admin",
  },
  MANAGE_SETTINGS: {
    id: "manage_settings",
    nameAr: "إدارة الإعدادات",
    nameEn: "Manage Settings",
    descriptionAr: "تعديل إعدادات النظام",
    descriptionEn: "Modify system settings",
    category: "admin",
  },
  VIEW_ADMIN_DASHBOARD: {
    id: "view_admin_dashboard",
    nameAr: "لوحة التحكم",
    nameEn: "Admin Dashboard",
    descriptionAr: "عرض لوحة تحكم المدير",
    descriptionEn: "View admin dashboard",
    category: "admin",
  },
  MANAGE_WASTE_ALERTS: {
    id: "manage_waste_alerts",
    nameAr: "إدارة تنبيهات الهدر",
    nameEn: "Manage Waste Alerts",
    descriptionAr: "إدارة إعدادات وحدود تنبيهات الهدر",
    descriptionEn: "Manage waste alert settings and thresholds",
    category: "admin",
  },
  MANAGE_NOTIFICATIONS: {
    id: "manage_notifications",
    nameAr: "إدارة الإشعارات",
    nameEn: "Manage Notifications",
    descriptionAr: "إرسال وإدارة الإشعارات",
    descriptionEn: "Send and manage notifications",
    category: "admin",
  },
};

// Define roles and their associated permissions
const ROLE_PERMISSIONS: Record<UserRole, RolePermissions> = {
  admin: {
    role: "admin",
    nameAr: "مدير النظام",
    nameEn: "System Admin",
    descriptionAr: "مسؤول النظام - صلاحيات كاملة على جميع الأقسام",
    descriptionEn: "System administrator - Full access to all sections",
    permissions: Object.values(PERMISSIONS),
  },

  production_manager: {
    role: "production_manager",
    nameAr: "مدير الإنتاج",
    nameEn: "Production Manager",
    descriptionAr: "إدارة كاملة لقسم الإنتاج ومراحل التصنيع",
    descriptionEn: "Full management of production and manufacturing stages",
    permissions: [
      PERMISSIONS.VIEW_PRODUCTION,
      PERMISSIONS.ADD_PRODUCTION,
      PERMISSIONS.EDIT_PRODUCTION,
      PERMISSIONS.DELETE_PRODUCTION,
      PERMISSIONS.EXPORT_PRODUCTION,
      PERMISSIONS.VIEW_MANUFACTURING,
      PERMISSIONS.ADD_MANUFACTURING,
      PERMISSIONS.EDIT_MANUFACTURING,
      PERMISSIONS.VIEW_WAREHOUSE,
      PERMISSIONS.VIEW_REPORTS,
      PERMISSIONS.VIEW_TASKS,
      PERMISSIONS.ADD_TASKS,
      PERMISSIONS.ASSIGN_TASKS,
      PERMISSIONS.MANAGE_WASTE_ALERTS,
    ],
  },

  warehouse_manager: {
    role: "warehouse_manager",
    nameAr: "أمين المستودع",
    nameEn: "Warehouse Manager",
    descriptionAr: "إدارة كاملة للمستودعات (الوارد والصادر)",
    descriptionEn: "Full warehouse management (incoming and outgoing)",
    permissions: [
      PERMISSIONS.VIEW_WAREHOUSE,
      PERMISSIONS.MANAGE_WAREHOUSE_IN,
      PERMISSIONS.MANAGE_WAREHOUSE_OUT,
      PERMISSIONS.EDIT_WAREHOUSE,
      PERMISSIONS.DELETE_WAREHOUSE,
      PERMISSIONS.VIEW_PRODUCTION,
      PERMISSIONS.VIEW_REPORTS,
      PERMISSIONS.VIEW_TASKS,
    ],
  },

  sales_manager: {
    role: "sales_manager",
    nameAr: "مدير المبيعات",
    nameEn: "Sales Manager",
    descriptionAr: "إدارة المبيعات والتحصيل",
    descriptionEn: "Sales and collection management",
    permissions: [
      PERMISSIONS.VIEW_SALES,
      PERMISSIONS.ADD_SALES,
      PERMISSIONS.EDIT_SALES,
      PERMISSIONS.DELETE_SALES,
      PERMISSIONS.VIEW_COLLECTION,
      PERMISSIONS.ADD_COLLECTION,
      PERMISSIONS.VIEW_WAREHOUSE,
      PERMISSIONS.VIEW_REPORTS,
      PERMISSIONS.EXPORT_REPORTS,
      PERMISSIONS.VIEW_TASKS,
    ],
  },

  maintenance_manager: {
    role: "maintenance_manager",
    nameAr: "مدير الصيانة",
    nameEn: "Maintenance Manager",
    descriptionAr: "إدارة الصيانة والسلامة المهنية",
    descriptionEn: "Maintenance and occupational safety management",
    permissions: [
      PERMISSIONS.VIEW_MAINTENANCE,
      PERMISSIONS.ADD_MAINTENANCE,
      PERMISSIONS.EDIT_MAINTENANCE,
      PERMISSIONS.DELETE_MAINTENANCE,
      PERMISSIONS.MANAGE_SAFETY,
      PERMISSIONS.VIEW_PRODUCTION,
      PERMISSIONS.VIEW_REPORTS,
      PERMISSIONS.VIEW_TASKS,
      PERMISSIONS.ADD_TASKS,
    ],
  },

  financial_manager: {
    role: "financial_manager",
    nameAr: "المدير المالي",
    nameEn: "Financial Manager",
    descriptionAr: "إدارة المصروفات والشؤون المالية",
    descriptionEn: "Financial and expense management",
    permissions: [
      PERMISSIONS.VIEW_FINANCIAL,
      PERMISSIONS.ADD_FINANCIAL,
      PERMISSIONS.EDIT_FINANCIAL,
      PERMISSIONS.APPROVE_FINANCIAL,
      PERMISSIONS.DELETE_FINANCIAL,
      PERMISSIONS.VIEW_SALES,
      PERMISSIONS.VIEW_COLLECTION,
      PERMISSIONS.VIEW_REPORTS,
      PERMISSIONS.EXPORT_REPORTS,
      PERMISSIONS.VIEW_TASKS,
    ],
  },

  hr_officer: {
    role: "hr_officer",
    nameAr: "مسؤول الموارد البشرية",
    nameEn: "HR Officer",
    descriptionAr: "إدارة شؤون الموظفين والإجازات والإصابات",
    descriptionEn: "Employee, leave, and injury management",
    permissions: [
      PERMISSIONS.VIEW_HR,
      PERMISSIONS.MANAGE_HR,
      PERMISSIONS.VIEW_INJURIES,
      PERMISSIONS.MANAGE_INJURIES,
      PERMISSIONS.MANAGE_SAFETY,
      PERMISSIONS.VIEW_TASKS,
      PERMISSIONS.ADD_TASKS,
      PERMISSIONS.ASSIGN_TASKS,
      PERMISSIONS.VIEW_REPORTS,
    ],
  },

  quality_inspector: {
    role: "quality_inspector",
    nameAr: "مفتش الجودة",
    nameEn: "Quality Inspector",
    descriptionAr: "فحص الجودة ومراقبة الهدر والنخب الثاني",
    descriptionEn: "Quality inspection and waste monitoring",
    permissions: [
      PERMISSIONS.VIEW_PRODUCTION,
      PERMISSIONS.VIEW_MANUFACTURING,
      PERMISSIONS.VIEW_WAREHOUSE,
      PERMISSIONS.MANAGE_WASTE_ALERTS,
      PERMISSIONS.VIEW_REPORTS,
      PERMISSIONS.EXPORT_PRODUCTION,
      PERMISSIONS.VIEW_TASKS,
    ],
  },

  operator: {
    role: "operator",
    nameAr: "مشغل",
    nameEn: "Operator",
    descriptionAr: "إدخال بيانات الإنتاج والتصنيع",
    descriptionEn: "Production and manufacturing data entry",
    permissions: [
      PERMISSIONS.VIEW_PRODUCTION,
      PERMISSIONS.ADD_PRODUCTION,
      PERMISSIONS.VIEW_MANUFACTURING,
      PERMISSIONS.ADD_MANUFACTURING,
      PERMISSIONS.VIEW_MAINTENANCE,
      PERMISSIONS.ADD_MAINTENANCE,
      PERMISSIONS.VIEW_TASKS,
    ],
  },

  user: {
    role: "user",
    nameAr: "مستخدم عام",
    nameEn: "General User",
    descriptionAr: "عرض البيانات فقط بدون تعديل",
    descriptionEn: "View-only access without editing",
    permissions: [
      PERMISSIONS.VIEW_PRODUCTION,
      PERMISSIONS.VIEW_SALES,
      PERMISSIONS.VIEW_WAREHOUSE,
      PERMISSIONS.VIEW_MAINTENANCE,
      PERMISSIONS.VIEW_TASKS,
    ],
  },
};

// Permission categories
export const PERMISSION_CATEGORIES = {
  production: { nameAr: "الإنتاج", nameEn: "Production", icon: "precision-manufacturing" },
  manufacturing: { nameAr: "مراحل التصنيع", nameEn: "Manufacturing", icon: "settings" },
  warehouse: { nameAr: "المستودعات", nameEn: "Warehouse", icon: "warehouse" },
  sales: { nameAr: "المبيعات والتحصيل", nameEn: "Sales & Collection", icon: "point-of-sale" },
  maintenance: { nameAr: "الصيانة", nameEn: "Maintenance", icon: "build" },
  financial: { nameAr: "المالية", nameEn: "Financial", icon: "account-balance" },
  tasks: { nameAr: "المهام", nameEn: "Tasks", icon: "task" },
  hr: { nameAr: "الموارد البشرية", nameEn: "Human Resources", icon: "people" },
  admin: { nameAr: "الإدارة والنظام", nameEn: "Admin & System", icon: "admin-panel-settings" },
};

export class RolesService {
  static getPermissionsForRole(role: UserRole): Permission[] {
    return ROLE_PERMISSIONS[role]?.permissions || [];
  }

  static hasPermission(role: UserRole, permissionId: string): boolean {
    const permissions = this.getPermissionsForRole(role);
    return permissions.some((p) => p.id === permissionId);
  }

  static getRoleDescription(role: UserRole, lang: "ar" | "en" = "ar"): string {
    const roleData = ROLE_PERMISSIONS[role];
    if (!roleData) return "Unknown role";
    return lang === "ar" ? roleData.descriptionAr : roleData.descriptionEn;
  }

  static getRoleName(role: UserRole, lang: "ar" | "en" = "ar"): string {
    const roleData = ROLE_PERMISSIONS[role];
    if (!roleData) return role;
    return lang === "ar" ? roleData.nameAr : roleData.nameEn;
  }

  static getAllRoles(): RolePermissions[] {
    return Object.values(ROLE_PERMISSIONS);
  }

  static getAllPermissions(): Permission[] {
    return Object.values(PERMISSIONS);
  }

  static getPermissionsByCategory(category: string): Permission[] {
    return Object.values(PERMISSIONS).filter((p) => p.category === category);
  }

  static getRolesByCategory(category: string): RolePermissions[] {
    return Object.values(ROLE_PERMISSIONS).filter((role) =>
      role.permissions.some((p) => p.category === category)
    );
  }

  static isAdminRole(role: UserRole): boolean {
    return role === "admin";
  }

  static isManagerRole(role: UserRole): boolean {
    return [
      "admin",
      "production_manager",
      "warehouse_manager",
      "sales_manager",
      "maintenance_manager",
      "financial_manager",
      "hr_officer",
    ].includes(role);
  }

  static canAccessSection(role: UserRole, section: string): boolean {
    const sectionPermissionMap: Record<string, string> = {
      production: "view_production",
      manufacturing: "view_manufacturing",
      warehouse: "view_warehouse",
      sales: "view_sales",
      collection: "view_collection",
      maintenance: "view_maintenance",
      financial: "view_financial",
      tasks: "view_tasks",
      hr: "view_hr",
      reports: "view_reports",
      admin_dashboard: "view_admin_dashboard",
      users_management: "manage_users",
      activity_log: "view_activity_log",
      waste_alerts: "manage_waste_alerts",
      export: "export_reports",
    };

    const requiredPermission = sectionPermissionMap[section];
    if (!requiredPermission) return true; // If no permission required, allow access
    return this.hasPermission(role, requiredPermission);
  }

  static getCommonPermissions(role1: UserRole, role2: UserRole): Permission[] {
    const permissions1 = this.getPermissionsForRole(role1);
    const permissions2 = this.getPermissionsForRole(role2);
    return permissions1.filter((p1) => permissions2.some((p2) => p1.id === p2.id));
  }

  static getUniquePermissions(role1: UserRole, role2: UserRole): Permission[] {
    const permissions1 = this.getPermissionsForRole(role1);
    const permissions2 = this.getPermissionsForRole(role2);
    return permissions1.filter((p1) => !permissions2.some((p2) => p1.id === p2.id));
  }
}

export { PERMISSIONS };
export default RolesService;
