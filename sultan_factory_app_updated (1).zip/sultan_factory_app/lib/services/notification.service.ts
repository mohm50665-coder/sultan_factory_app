import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Notifications from "expo-notifications";

export interface Notification {
  id: string;
  title: string;
  body: string;
  type: "task_completed" | "equipment_stopped" | "waste_exceeded" | "alert" | "info";
  timestamp: Date;
  read: boolean;
  data?: Record<string, any>;
}

const NOTIFICATIONS_KEY = "notifications";
const NOTIFICATION_SETTINGS_KEY = "notification_settings";

// إعداد معالج الإشعارات
Notifications.setNotificationHandler({
  handleNotification: async () => {
    return {
      shouldShowAlert: true,
      shouldPlaySound: true,
      shouldSetBadge: true,
    } as Notifications.NotificationBehavior;
  },
});

interface NotificationSettings {
  taskCompleted: boolean;
  equipmentStopped: boolean;
  wasteExceeded: boolean;
  alerts: boolean;
  soundEnabled: boolean;
  vibrationEnabled: boolean;
}

const DEFAULT_SETTINGS: NotificationSettings = {
  taskCompleted: true,
  equipmentStopped: true,
  wasteExceeded: true,
  alerts: true,
  soundEnabled: true,
  vibrationEnabled: true,
};

class NotificationService {
  /**
   * تهيئة الإشعارات
   */
  async initialize(): Promise<void> {
    try {
      // طلب إذن الإشعارات
      const { status } = await Notifications.requestPermissionsAsync();
      if (status !== "granted") {
        console.warn("Notification permission not granted");
      }

      // تهيئة الإعدادات الافتراضية
      const settings = await AsyncStorage.getItem(NOTIFICATION_SETTINGS_KEY);
      if (!settings) {
        await AsyncStorage.setItem(
          NOTIFICATION_SETTINGS_KEY,
          JSON.stringify(DEFAULT_SETTINGS)
        );
      }
    } catch (error) {
      console.error("Error initializing notifications:", error);
    }
  }

  /**
   * إرسال إشعار محلي
   */
  async sendNotification(
    title: string,
    body: string,
    type: Notification["type"],
    data?: Record<string, any>
  ): Promise<void> {
    try {
      const settings = await this.getSettings();

      // التحقق من إعدادات الإشعارات
      if (!this.shouldSendNotification(type, settings)) {
        return;
      }

      // إرسال الإشعار
      await Notifications.scheduleNotificationAsync({
        content: {
          title,
          body,
          sound: settings.soundEnabled ? "default" : undefined,
          vibrate: settings.vibrationEnabled ? [0, 250, 250, 250] : undefined,
          data: data || {},
        },
        trigger: null, // إرسال فوري
      });

      // حفظ الإشعار في السجل
      await this.saveNotification({
        id: Date.now().toString(),
        title,
        body,
        type,
        timestamp: new Date(),
        read: false,
        data,
      });
    } catch (error) {
      console.error("Error sending notification:", error);
    }
  }

  /**
   * Task completion notification
   */
  async notifyTaskCompleted(taskName: string, completedBy: string, lang: "ar" | "en" = "ar"): Promise<void> {
    const title = lang === "ar" ? "تم إكمال المهمة" : "Task Completed";
    const message = lang === "ar" 
      ? `تم إكمال مهمة "${taskName}" بواسطة ${completedBy}`
      : `Task "${taskName}" completed by ${completedBy}`;
    await this.sendNotification(title, message, "task_completed", { taskName, completedBy });
  }

  /**
   * Equipment stopped notification
   */
  async notifyEquipmentStopped(
    equipmentName: string,
    reason: string,
    lang: "ar" | "en" = "ar"
  ): Promise<void> {
    const title = lang === "ar" ? "توقف الجهاز" : "Equipment Stopped";
    const message = lang === "ar"
      ? `توقف جهاز "${equipmentName}" - السبب: ${reason}`
      : `Equipment "${equipmentName}" stopped - Reason: ${reason}`;
    await this.sendNotification(title, message, "equipment_stopped", { equipmentName, reason });
  }

  /**
   * Waste exceeded notification
   */
  async notifyWasteExceeded(
    percentage: number,
    limit: number,
    lang: "ar" | "en" = "ar"
  ): Promise<void> {
    const title = lang === "ar" ? "تحذير: تجاوز الهدر" : "Warning: Waste Exceeded";
    const message = lang === "ar"
      ? `معدل الهدر الحالي ${percentage}% تجاوز الحد المسموح به ${limit}%`
      : `Current waste rate ${percentage}% exceeded the allowed limit ${limit}%`;
    await this.sendNotification(title, message, "waste_exceeded", { percentage, limit });
  }

  /**
   * General alert notification
   */
  async notifyAlert(title: string, message: string): Promise<void> {
    await this.sendNotification(title, message, "alert");
  }

  /**
   * Information notification
   */
  async notifyInfo(title: string, message: string): Promise<void> {
    await this.sendNotification(title, message, "info");
  }

  /**
   * حفظ الإشعار في السجل
   */
  private async saveNotification(notification: Notification): Promise<void> {
    try {
      const notificationsJson = await AsyncStorage.getItem(NOTIFICATIONS_KEY);
      const notifications: Notification[] = notificationsJson
        ? JSON.parse(notificationsJson)
        : [];

      notifications.unshift(notification);

      // الاحتفاظ بآخر 100 إشعار فقط
      if (notifications.length > 100) {
        notifications.pop();
      }

      await AsyncStorage.setItem(
        NOTIFICATIONS_KEY,
        JSON.stringify(notifications)
      );
    } catch (error) {
      console.error("Error saving notification:", error);
    }
  }

  /**
   * الحصول على جميع الإشعارات
   */
  async getAllNotifications(): Promise<Notification[]> {
    try {
      const notificationsJson = await AsyncStorage.getItem(NOTIFICATIONS_KEY);
      return notificationsJson ? JSON.parse(notificationsJson) : [];
    } catch (error) {
      console.error("Error getting notifications:", error);
      return [];
    }
  }

  /**
   * الحصول على الإشعارات غير المقروءة
   */
  async getUnreadNotifications(): Promise<Notification[]> {
    try {
      const notifications = await this.getAllNotifications();
      return notifications.filter((n) => !n.read);
    } catch (error) {
      console.error("Error getting unread notifications:", error);
      return [];
    }
  }

  /**
   * تحديد الإشعار كمقروء
   */
  async markAsRead(notificationId: string): Promise<void> {
    try {
      const notifications = await this.getAllNotifications();
      const notification = notifications.find((n) => n.id === notificationId);

      if (notification) {
        notification.read = true;
        await AsyncStorage.setItem(
          NOTIFICATIONS_KEY,
          JSON.stringify(notifications)
        );
      }
    } catch (error) {
      console.error("Error marking notification as read:", error);
    }
  }

  /**
   * تحديد جميع الإشعارات كمقروءة
   */
  async markAllAsRead(): Promise<void> {
    try {
      const notifications = await this.getAllNotifications();
      notifications.forEach((n) => {
        n.read = true;
      });
      await AsyncStorage.setItem(
        NOTIFICATIONS_KEY,
        JSON.stringify(notifications)
      );
    } catch (error) {
      console.error("Error marking all notifications as read:", error);
    }
  }

  /**
   * حذف الإشعار
   */
  async deleteNotification(notificationId: string): Promise<void> {
    try {
      const notifications = await this.getAllNotifications();
      const filtered = notifications.filter((n) => n.id !== notificationId);
      await AsyncStorage.setItem(
        NOTIFICATIONS_KEY,
        JSON.stringify(filtered)
      );
    } catch (error) {
      console.error("Error deleting notification:", error);
    }
  }

  /**
   * حذف جميع الإشعارات
   */
  async deleteAllNotifications(): Promise<void> {
    try {
      await AsyncStorage.removeItem(NOTIFICATIONS_KEY);
    } catch (error) {
      console.error("Error deleting all notifications:", error);
    }
  }

  /**
   * الحصول على إعدادات الإشعارات
   */
  async getSettings(): Promise<NotificationSettings> {
    try {
      const settingsJson = await AsyncStorage.getItem(NOTIFICATION_SETTINGS_KEY);
      return settingsJson ? JSON.parse(settingsJson) : DEFAULT_SETTINGS;
    } catch (error) {
      console.error("Error getting notification settings:", error);
      return DEFAULT_SETTINGS;
    }
  }

  /**
   * تحديث إعدادات الإشعارات
   */
  async updateSettings(
    settings: Partial<NotificationSettings>
  ): Promise<void> {
    try {
      const currentSettings = await this.getSettings();
      const updatedSettings = { ...currentSettings, ...settings };
      await AsyncStorage.setItem(
        NOTIFICATION_SETTINGS_KEY,
        JSON.stringify(updatedSettings)
      );
    } catch (error) {
      console.error("Error updating notification settings:", error);
    }
  }

  /**
   * التحقق من ما إذا كان يجب إرسال الإشعار
   */
  private shouldSendNotification(
    type: Notification["type"],
    settings: NotificationSettings
  ): boolean {
    switch (type) {
      case "task_completed":
        return settings.taskCompleted;
      case "equipment_stopped":
        return settings.equipmentStopped;
      case "waste_exceeded":
        return settings.wasteExceeded;
      case "alert":
        return settings.alerts;
      case "info":
        return true;
      default:
        return true;
    }
  }
}

export const notificationService = new NotificationService();
