#!/bin/bash
echo "🔨 جاري بناء التطبيق..."

# Create a simple APK using prebuild
npx expo prebuild --clean 2>&1 | tail -10

if [ -d "android" ]; then
  echo "✅ تم إنشاء مجلد Android"
  cd android
  ./gradlew assembleRelease 2>&1 | tail -20
  cd ..
  
  if [ -f "android/app/build/outputs/apk/release/app-release.apk" ]; then
    echo "✅ تم بناء APK بنجاح!"
    cp android/app/build/outputs/apk/release/app-release.apk /home/ubuntu/sultan_factory_app.apk
    echo "📦 الملف: /home/ubuntu/sultan_factory_app.apk"
  fi
else
  echo "❌ فشل إنشاء مجلد Android"
fi
